/**
 * Eclipse System - Theme Toggle Script
 * Handles manual theme switching if needed (optional feature)
 */

// Detect system theme preference
function detectTheme() {
    const isDarkMode = window.matchMedia('(prefers-color-scheme: dark)').matches;
    return isDarkMode ? 'dark' : 'light';
}

// Listen for system theme changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    const newTheme = e.matches ? 'dark' : 'light';
    console.log(`System theme changed to: ${newTheme}`);
});

// Log current theme on page load
document.addEventListener('DOMContentLoaded', () => {
    const currentTheme = detectTheme();
    console.log(`Eclipse System initialized with ${currentTheme} theme`);
});

// Optional: Manual theme toggle function (can be used with a button)
function toggleTheme() {
    // This function can be extended to manually override system preference
    // Currently, the theme automatically follows system preference
    console.log('Theme toggle triggered');
}
